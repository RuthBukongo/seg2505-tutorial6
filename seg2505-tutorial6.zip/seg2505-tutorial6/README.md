# seg2505-tutorial6
uOttawa - 2024-2025 - SEG2505A - Tutoriel 6 - Android UI
Il s'agit de l'ajout d'une mise en page plus dynamiques offrant plus de fexibilité aux utilisateurs 

- Le tutoriel réalisé:
* Bases du Material Design (Java)
  MDC-102 Android: Material Structure and Layout (Java)
 (obligatoire)

# Lien vers le dépot github

https://github.com/Bruno025/seg2505-tutorial6

# N.B:
* Référence pour ce tutoriel: https://github.com/material-components/material-components-android-codelabs